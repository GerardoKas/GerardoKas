use File::Find;
use HTML::TreeBuilder;
use HTML::Element;

use HTML::Tidy;
use strict;
use warnings;

#BEGIN
my @files      = @ARGV;
my $files_proc = "";

my $debug = 0;

#print $files[0];
if ( -d $files[0] ) {
    print "Now: ";
    $files_proc = 0;
    File::Find::find( \&ReplacePanes, $files[0] );
    print "Done;\n";
    print "$files_proc Ficheros procesados\n\n";
    exit;
}
else {
    foreach (@files) {
        ReplacePanes($_);
        print " Un fihero tratado --> $_\n";
        exit;

    }
}

sub ReplacePanes {
    my $fichero = $_;
    return unless ( $fichero =~ /\.html?$/i );
    print "Reading ... ";
    my $root = HTML::TreeBuilder->new_from_file($fichero);

    #$root->delete_ignorable_whitespace();
    $root->elementify;
    my $cuantos = 0;

#PREL TYIDY - -_   use Perl::Tidy; my $source_string = <<'EOT'; # this is comment remove it =another pod also remove this pod line =cut my $error = Perl::Tidy::perltidy( argv => $argv, source => \$ …
    if (1) {

#$root->elementify;    # Make $root into an HTML::Element object;
            #$e->content_list;
#for my $e ( $root->look_down( _tag => 'div', class => 'header-holder has-default-focus' ) ) {
        for my $e ( $root->look_down( _tag => 'div' ) ) {
            $e->delete_content;
            $cuantos++;
        }
        for my $e ( $root->look_down( _tag =>'td',id=>'menubar_holder' ) ) {
            $e->delete_content;
            $cuantos++;
        }
        
        print "Cuantos Elementos TRatados -> $cuantos\n";
        my $new_html ;
        print $root->as_HTML;
        #my $name = $fichero=~/\\(\w+)\.$/;
        #print $name;
    
        open( FILE, ">codehtml".".html" ) or die "cantopen file-$!";       
        print FILE $new_html;
        close FILE;

        # print "  (-" . $root->dump() . "-\n";

    }

    if (0) {
        my $data = $root->look_down(
            _tag  => 'div',
            class => undef
        );
        $root->delete_content;
        print ":: " . $data . " ::\n";

        $data->delete_content;
        print $data->content_list, "\n" if $data;
    }

    #print $root->as_HTML;

    #print " * Saving.\n";
    # rename($fichero,"$fichero\.bak");
    #open(SAVE,">$fichero") or die "canot open for save $fichero";
    #print SAVE $todo_texto;
    #close SAVE;
}

sub deleteLineBreaks() {
    my $num_spaces = $_ =~ s/([\n]+)/\n/mgsi;
    print "Espacios->" . $num_spaces . "<\n";
    return $_;
}
__END__
