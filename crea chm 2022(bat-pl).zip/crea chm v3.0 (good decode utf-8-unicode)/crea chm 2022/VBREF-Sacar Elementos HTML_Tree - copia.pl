use File::Find;
use HTML::TreeBuilder;
use HTML::Element;
#BEGIN
my @files=@ARGV;
#print $files[0];
if (-d $files[0]){
  print "Now: ";
  $files_proc=0;
    File::Find::find(\&ReplacePanes,$files[0]);
    print "Done;\n";
    print "$files_proc Ficheros procesados\n\n";
  }else{
    foreach(@files){ReplacePanes($_);
    print " Un fihero tratado --> $_\n";
    exit;

  }
}
sub ReplacePanes{
  $fichero=$_;
  return unless ($fichero=~/\.html?$/i);
  print "Reading ... ";
  if (0){
  my $h = HTML::TreeBuilder->new_from_file($fichero);
  print "<<<". $h->dump().">>>\n";
  my $data = $h->look_down(
    _tag  => 'header',
   # class => 'ins'
      );
      $data->innerHTML="";
 print $data->dump;

print $data->content_list, "\n" if $data; 
}
  #print " * Saving.\n";
 # rename($fichero,"$fichero\.bak");
  #open(SAVE,">$fichero") or die "canot open for save $fichero";
  #print SAVE $todo_texto;
  #close SAVE;
}

sub deleteLineBreaks(){
  my $num_spaces=$_=~s/([\n]+)/\n/mgsi;
    print "Espacios->".$num_spaces."<\n";
    return $_;
}
__END__
